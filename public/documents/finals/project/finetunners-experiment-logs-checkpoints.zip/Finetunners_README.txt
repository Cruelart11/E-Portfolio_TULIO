README: RAG EXPERIMENT FILES

Project: Making Wage Rules Legible: A RAG Chatbot for Minimum-Wage Workers in Metro Manila

This archive contains the CPU and GPU results for Runs A to F and the three PDF documents used as the chatbot's knowledge base.

SUGGESTED FOLDER ORGANIZATION

1_Experimental_Results
  Run_A
  Run_B
  Run_C
  Run_D
  Run_E
  Run_F

2_Source_Documents


EXPERIMENTAL RESULT FILES

Each Run folder contains four files:

Run_[Letter]_CPU_Raw_Results.csv
Contains the individual CPU measurements for every question and repetition, including timing, generated answers, and retrieved-source information.

Run_[Letter]_CPU_Experimental_Results.xlsx
Contains the organized CPU experimental records and summary for the run.

Run_[Letter]_GPU_Raw_Results.csv
Contains the individual T4 GPU measurements for every question and repetition, including timing, generated answers, and retrieved-source information.

Run_[Letter]_GPU_Experimental_Results.xlsx
Contains the organized T4 GPU experimental records and summary for the run.

The letters A to F represent these configurations:

Run A: Chunk size 400, overlap 50, Top-k 3
Run B: Chunk size 800, overlap 100, Top-k 3
Run C: Chunk size 1,200, overlap 150, Top-k 3
Run D: Chunk size 800, overlap 200, Top-k 3
Run E: Chunk size 800, overlap 100, Top-k 5
Run F: Chunk size 1,000, overlap 200, Top-k 3


SOURCE DOCUMENTS

Labor-Code-of-the-Philippines.pdf
Provides the general Philippine labor provisions used by the chatbot, including normal working hours.

Wage-Order-No.-NCR-27.pdf
Provides the Metro Manila minimum-wage rates examined in the experiment. OCR was applied to make the scanned document searchable.

Workers-Statutory-Monetary-Benefits-Handbook-2024-Edition.pdf
Provides explanations and computation rules for statutory monetary benefits, including holiday and premium pay.


PURPOSE OF THE ARCHIVE

These files document the comparison of chunking and retrieval configurations on Google Colab CPU and T4 GPU. They support the reported indexing times, average response times, CPU-to-GPU speedups, retrieved evidence, and answer-quality assessments.

Configuration C, using a chunk size of 1,200, an overlap of 150, and Top-k 3, was the recommended configuration based on the combined timing, retrieval, and answer-quality results.

The materials are intended for academic evaluation. Generated answers should be checked against the original government documents and should not be treated as professional legal advice.
